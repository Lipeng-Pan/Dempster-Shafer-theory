function [complexD]=complexdistance(CM1,CM2,p)

   
   R=[1.0000         0             0.5000    
         0           1.0000            0.5000        
        0.5         0.5                 1.0000];
  
  
complexD=(((R*(CM1-CM2).').^(p/2))'*((R*(CM1-CM2).').^(p/2))/(CM1.^(p/2)*(CM1.^(p/2))'+CM2.^(p/2)*(CM2.^(p/2))'))^0.5;




end
 

 
   
  
  
  
