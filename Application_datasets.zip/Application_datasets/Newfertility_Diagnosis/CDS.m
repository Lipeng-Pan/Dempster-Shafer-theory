 function [outputArg1] = CDS(mp1,mp2)

 

F1=[1     0    1
    0     0     0
    1     0     0];

F2=[0     0     0     
    1     0    1    
    0     1     0];

F3=[0     0     0  
    0     0     0
    0     0     1]; 
 DM=mp1'*mp2;
 
 DV=[sum(sum(DM.*F1)),sum(sum(DM.*F2)),sum(sum(DM.*F3))];
 outputArg1=(DV.^2/(sum(( abs(DV)).^2))).^0.5;
 

end

