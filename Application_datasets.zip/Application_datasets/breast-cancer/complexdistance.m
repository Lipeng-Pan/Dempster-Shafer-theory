function [complexD]=complexdistance(CM1,CM2,p)

   
   W=[1.0000         0             0.5000    
         0           1.0000            0.5000        
        0.5         0.5                 1.0000];
  
  
cholesky_D=chol(W);
  
  
complexD=(((cholesky_D*(CM1-CM2).').^(p/2))'*((cholesky_D*(CM1-CM2).').^(p/2))/(CM1.^(p/2)*(CM1.^(p/2))'+CM2.^(p/2)*(CM2.^(p/2))'))^0.5;




end
 

 
   
  
  
  
