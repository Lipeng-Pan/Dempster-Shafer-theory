DataO=xlsread('C:\Users\Li_Peng_Pan\Desktop\INS-D-22-5070\CSE_INS\INS_matlab\Z_computational complexity\ELE.xlsx');


DataO=DataO'
M1=DataO;

 
x=2:1:8;
h1=plot(x,M1(2,:),'--og','LineWidth',1);
ylabel('Execution time');
xlabel('Size of frame of discernment');
set(gca,'FontName','Times New Roman','FontSize',30);


figure



M2=DataO(:,1:5);


 
x=2:1:6;
h1=plot(x,M2(5,:),'--og','LineWidth',1);

ylabel('Execution time');
xlabel('Size of frame of discernment');
set(gca,'FontName','Times New Roman','FontSize',30);

