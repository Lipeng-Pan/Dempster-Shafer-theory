DataO=xlsread('C:\Users\Li_Peng_Pan\Desktop\INS-D-22-5070\CSE_INS\INS_matlab\Z_computational complexity\Mass\I_MASS_V.xlsx');



M1=DataO;


 
x=2:1:100;
h1=plot(x,M1(1,:),'--og','LineWidth',1);

ylabel('Execution time');
xlabel('Number of mass functions of the combination');
set(gca,'FontName','Times New Roman','FontSize',30);


