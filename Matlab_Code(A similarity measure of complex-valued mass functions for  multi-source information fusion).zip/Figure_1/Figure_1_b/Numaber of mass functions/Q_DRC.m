function [ ]=Q_DRC(i_mass)
c=4;
mass_function_1_R=rand(i_mass,2^c-1);
mass_function_1_I=rand(i_mass,2^c-1);
mass_function_1=mass_function_1_R+1i*mass_function_1_I;

mass_function_1=(mass_function_1.^2./(sum(( abs(mass_function_1)).^2,2))).^0.5; 

   mp1=mass_function_1(1,:);
   mp2=mass_function_1(2,:);
     [outputArg1]=CDS(mp1,mp2);
     for mmk=3:1:i_mass
         mp1=outputArg1;
         mp2=mass_function_1(mmk,:);
         [outputArg1]=CDS(mp1,mp2);
     end
   


end