
II_Time=100;

I_MASS_number=100;

I_MASS_V=zeros(1,I_MASS_number-1);



kkk=0;
N1=2;
for i_mass=N1:1:I_MASS_number
    kkk=kkk+1
    

Time_V=zeros(1,II_Time);
for i_time=2:1:II_Time+1




tic
Q_DRC(i_mass)
Time_V(1,i_time-1)=toc;


end

I_MASS_V(:,kkk)=sum(Time_V,2);
end
I_MASS_V
     xlswrite('/Users/panlipeng/Desktop/CSE_INS/INS_matlab/Z_computational complexity/Mass/I_MASS_V.csv',I_MASS_V)