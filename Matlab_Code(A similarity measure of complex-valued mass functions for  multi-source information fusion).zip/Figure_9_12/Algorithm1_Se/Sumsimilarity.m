clear all
clc
 j=12;
number=j/4;
[DataSW]=CBPASW(number);
[DataSL]=CBPASL(number);
[DataPW]=CBPASW(number);
[DataPL]=CBPASW(number);

cBPA=[DataSW;
      DataSL;
      DataPW;
      DataPL];





%% �������ƶ�
D= [1 0 0 1/3 1/3 0 1/7
   0 1 0 1/3 0 1/3 1/7
   0 0 1 0 1/3 1/3 1/7
   1/3 1/3 0 1 1/9 1/9 3/7
   1/3 0 1/3 1/9 1 1/9 3/7
   0 1/3 1/3 1/9 1/9 1 3/7
   1/7 1/7 1/7 3/7 3/7 3/7 1];

  Sm=zeros(j,j);
  for m=1:1:j
      for n=1:1:j        
        x=cBPA(m,:);
        y=cBPA(n,:);  
        Sm(m,n)=abs((x*D*y')/(x*D*x'*(y*D*y'))^0.5);
      end
  end
  Sm;
  

  w=(sum(Sm)-1)/(sum(sum(Sm))-j);

  
[vule,location]=sort(w,'descend');
cBPA=cBPA(location,1:7);

%% ������CBPA

  Smorder=zeros(j,j);
  for m=1:1:j
      for n=1:1:j        
        x=cBPA(m,:);
        y=cBPA(n,:);  
        Smorder(m,n)=abs((x*D*y')/(x*D*x'*(y*D*y'))^0.5);
      end
  end
  Smorder
  triuSmorder=triu(Smorder,0)
  %% ֤���ں�
SunBPA=cBPA(1,:);
n_class = 3;
P = [1 2 3 12 13 23 123];
L = length(P);
cBPA_P=[cBPA(1,:);cBPA];
mp1 =cBPA_P(1,:);
fusion=zeros(j,7);
fusion(1,:)=mp1;
conflict=zeros(1,j);
fusionsimilarity=zeros(1,j);

fusionvule=zeros(j,7);
fusionvule(1,:)=abs(mp1);
for n=2:1:j+1
   
mp2 =cBPA_P(n,:);
fusionsimilarity(n-1)=abs((mp1*D*mp2')/(mp1*D*mp1'*(mp2*D*mp2'))^0.5);


mp = zeros(1,L);

for k = 1:L
    F_k = zeros(L,L);
    label = num2str(P(k));
    for m = 1:L
        label_i = num2str(P(m));
        for c = 1:L
            label_j = num2str(P(c));
            itersect_ij = intersect(label_i,label_j);
            if strcmp(itersect_ij,label)      
                F_k(m,c) = 1;
            end  
        end
    end  
    mp(k) = sum(sum(mp1.'*mp2.*F_k));
end
mp;

clear i;
sumBPA=0;
for kk=1:1:7
    sumBPA=sumBPA+(abs(mp(kk)));
end
conflict(n-1)=1-sumBPA;
mp=mp/(sumBPA);
mp1=mp;
mp;
abs(mp);
 fusion(n-1,:)=mp;
 fusionvule(n-1,:)=abs(mp);
end

 conflict
 fusionsimilarity
 fusion;
 fusionvule
