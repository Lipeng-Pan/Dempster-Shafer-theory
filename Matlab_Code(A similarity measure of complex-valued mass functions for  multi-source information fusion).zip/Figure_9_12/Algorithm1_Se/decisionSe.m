

 y=[0.7118           0.2882    
    0.9164        0.0836    
    0.9757       0.0243    
    0.9919        0.0081    
    0.9973       0.0027   
    0.9994        0.0006    
    0.9999       0.0001   
    1.0000        0.0000    
    1.0000            0.0000    
    1.0000       0.0000    
    1.0000        0.0000   
    1.0000       0.0000   ];


yy=[1 1.0000   0.9706    0.9347    0.9294    0.9727    0.9762    0.9763    1.0000    1.0000    0.2028    0.0464];

x=[1 2 3 4 5 6 7 8 9 10 11 12];
   b=bar(x,y,1.0);

 hold on
  legend([b],'{Se}','{Se,Vi}','location','northeastoutside');

set(gca, 'XTickLabel', {'1','2','3','4','5','6','7','8','9','10','11','12'});
  xlabel('{CM}_{fl}(i=1,...,12)');
  yyaxis left
 ylabel('Combined result');
hold on
grid on
 yyaxis right 
 ylabel('Complex similarity measure');
p = plot(x,yy,'-k*','LineWidth',1.5);
  legend('{Se}','{Se,Vi}','CSM')
   set(gca,'FontName','Times New Roman','FontSize',30);
