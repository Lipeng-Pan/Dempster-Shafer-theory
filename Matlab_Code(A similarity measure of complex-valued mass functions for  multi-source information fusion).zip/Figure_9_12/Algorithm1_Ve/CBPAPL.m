function [DataPL]=CBPAPL(number)
Data=xlsread('irisPL.csv');

%% �����ֵ����Сֵ��ƽ��ֵ
 DataSetosa=Data(1:50,2);
 Dataversicolor=Data(51:100,2);
 DataVirginica=Data(101:150,2);

 
 n=50;
 DataSe=randperm(numel(DataSetosa));
 DataSetosa=DataSetosa(DataSe(1:n));
 
 DataVe=randperm(numel(Dataversicolor));
 Dataversicolor=Dataversicolor(DataVe(1:n));
 
 DataVi=randperm(numel(DataVirginica));
 DataVirginica=DataVirginica(DataVi(1:n)); 
 
 
 DataSetosamin=min(DataSetosa);
 DataSetosamax=max(DataSetosa);
 DataSetosamean=mean(DataSetosa);
 
 Dataversicolormin=min(Dataversicolor);
 Dataversicolormax=max(Dataversicolor);
 Dataversicolormean=mean(Dataversicolor);

 DataVirginicamin=min(DataVirginica);
 DataVirginicamax=max(DataVirginica);
 DataVirginicamean=mean(DataVirginica);
 
 ivule=[DataSetosamean,Dataversicolormean,DataVirginicamean,(DataSetosamean+Dataversicolormean)/2,(DataSetosamean+DataVirginicamean)/2,(Dataversicolormean+DataVirginicamean)/2,(DataSetosamean+Dataversicolormean+DataVirginicamean)/3];
 %% ����Setosa������ģ����
 
 DataSetosacoefficientfrist=polyfit([DataSetosamin DataSetosamean],[0 1],1);
 DataSetosacoefficientsecond=polyfit([DataSetosamean DataSetosamax],[1 0],1);
 
 xSetosa=DataSetosamin:0.02:DataSetosamax;
 fSetosa=@(x)  (DataSetosacoefficientfrist(1)*x+DataSetosacoefficientfrist(2)) .*(x>=DataSetosamin & x<=DataSetosamean)  +(DataSetosacoefficientsecond(1)*x+DataSetosacoefficientsecond(2)).*(x>DataSetosamean& x<=DataSetosamax);
 
%  Setosafrist=(xSetosa<=DataSetosamean);
%  Setosasecond=(xSetosa>DataSetosamean);
 
 fSetosa(xSetosa);
%  figure;
%  plot(xSetosa,fSetosa(xSetosa),'-*');

 %% ����versicolor������ģ����

 Dataversicolorcoefficientfrist=polyfit([Dataversicolormin Dataversicolormean],[0 1],1);
 Dataversicolorcoefficientsecond=polyfit([Dataversicolormean Dataversicolormax],[1 0],1);
 
 xversicolor=Dataversicolormin:0.02:Dataversicolormax;
 fversicolor=@(x)  (Dataversicolorcoefficientfrist(1)*x+Dataversicolorcoefficientfrist(2)) .*(x>=Dataversicolormin & x<=Dataversicolormean)  +(Dataversicolorcoefficientsecond(1)*x+Dataversicolorcoefficientsecond(2)).*(x>Dataversicolormean& x<=Dataversicolormax);
 
%  Setosafrist=(xSetosa<=DataSetosamean);
%  Setosasecond=(xSetosa>DataSetosamean);
 
 fversicolor(xversicolor);
%  figure;
%  plot(xversicolor,fversicolor(xversicolor),'-*');
 

  %% ����Virginica������ģ����
  
 DataVirginicacoefficientfrist=polyfit([DataVirginicamin DataVirginicamean],[0 1],1);
 DataVirginicacoefficientsecond=polyfit([DataVirginicamean DataVirginicamax],[1 0],1);
 
 xVirginica=DataVirginicamin:0.02:DataVirginicamax;
 
 fVirginica=@(x)  (DataVirginicacoefficientfrist(1)*x+DataVirginicacoefficientfrist(2)) .*(x>=DataVirginicamin & x<=DataVirginicamean)  +(DataVirginicacoefficientsecond(1)*x+DataVirginicacoefficientsecond(2)).*(x>DataVirginicamean& x<=DataVirginicamax);
 
%  Setosafrist=(xSetosa<=DataSetosamean);
%  Setosasecond=(xSetosa>DataSetosamean);
 
 fVirginica(xVirginica);
%  figure;
%  plot(xVirginica,fVirginica(xVirginica),'-*');

 
 %% ��ͼ������ģ������
 
 
%  figure;
%  plot(xSetosa,fSetosa(xSetosa),'.',xversicolor,fversicolor(xversicolor),'*',xVirginica,fVirginica(xVirginica),'-');

 %% �󽻵�
 element={'A','B','C'};
 
 j=number;  % ȫ�ֱ���
 
 Datatrans=randperm(numel(Dataversicolor));
 Datatransdet=Dataversicolor(Datatrans(1:j)); 
%  Datatrans=randperm(numel(DataSetosa));
%  Datatransdet=DataSetosa(Datatrans(1:j)); 
 BPA=zeros(j,7);
 imageBPA=zeros(j,7);
 cBPA=zeros(j,7);
 angle=zeros(j,7);
% element={'A','B','C'};
for p=1:1:j
 Intersection=[fSetosa(Datatransdet(p));fversicolor(Datatransdet(p));fVirginica(Datatransdet(p))];
%% ����޴���BPA
[vule,location]=sort(Intersection,'descend');
% if (vule(1)+vule(2)+vule(3)==0)
%     vule=vule;
% else 
% vule=vule/(vule(1)+vule(2)+vule(3));
% end
frist=[element(location(1)),vule(1)];
second=[strcat(element(location(1)),element(location(2))),vule(2)];
third=[strcat(element(location(1)),element(location(2)),element(location(3))),vule(3)];
BPAdisorder=[frist;second;third];


%%  ����д���BPA
image=[0,0,0,0,0,0,0];

elementOrder={'A','B','C','AB','AC','BC','ABC'};
BPAvule=[0 0 0 0 0 0 0];
BPAvule(7)=vule(3);%��Ԫ���ı�ʱ��һ��Ҫ�ı丳ֵ�ķ�ʽ
if (BPAvule(7)==0)
   image(7)=0;
else
image(7)=(ivule(7)-Datatransdet(p))/ivule(7);
end
for iiii=1:1:3
    ii=isequal(sort(cell2mat(elementOrder(iiii))),sort(cell2mat(frist(1))));
    if(ii==1)
       BPAvule(iiii)=vule(1);
       image(iiii)=(ivule(iiii)-Datatransdet(p))/ivule(iiii);
    end
end

for iiii=4:1:6
    ii=isequal(sort(cell2mat(elementOrder(iiii))),sort(cell2mat(second(1))));
    if(ii==1)
        BPAvule(iiii)=vule(2);
 %       image(i)=(ivule(i)-Datatransdet(p))/ivule(i);
        if(BPAvule(iiii)==0)
          image(iiii)=0;
        else
        image(iiii)=(ivule(iiii)-Datatransdet(p))/ivule(iiii);
        end
    end
 end

BPAvule;
image;
 BPA(p,1:7)=BPAvule;
 imageBPA(p,1:7)=image;
end
BPA;
% xlswrite('F:\����\֤�����۵����ƶȲ���\BPA\transdata',BPA)   %�������ݵ���xls






%% ��BPA�г��ֵ�0ֵ���д���
for iiii=1:1:j
    for k=1:1:7 
        if (BPA(iiii,k)==0)
          BPA(iiii,k)=1.0000e-16;
        end
    end
end
BPA;
imageBPA;
pangle=abs(atan(imageBPA./BPA));
pangle(find(pangle>(pi/2))) =pi/2;

%% ����ģֵ
die=zeros(j,7);
die=(BPA.^2+imageBPA.^2).^0.5;
for iiii=1:1:j
    die(iiii,1:7)=die(iiii,1:7)/(sum(die(iiii,:)));
end
die;
% clear i;
cBPA=die.*(cos(pangle)+i.*sin(pangle));
DataPL=cBPA;
end