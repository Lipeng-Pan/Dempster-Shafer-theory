



y=[    0.4371    0.0000            0.3559    0.2070 ;
        0.7020    0.0000            0.2578    0.0402 ;
        0.8501    0.0000            0.1419    0.0079 ;
       0.9247    0.0000            0.0738    0.0016 ;
       0.9656    0.0000            0.0344    0.0000 ;
        0.9868    0.0000            0.0132    0.0000  ;
       0.9781    0.0089            0.0130    0.0000 ;
       0.9618    0.0254           0.0128    0.0000 ;
       0.9073    0.0806           0.0121    0.0000 ;
       0.9042    0.0833            0.0125    0.0000 ;
        0.7434    0.2463           0.0103    0.0000 ;
      0.3853    0.6094            0.0053    0.0000  ];
x=[1 2 3 4 5 6 7 8 9 10 11 12];
   b=bar(x,y,1.0);

 hold on
  legend([b],'{Ve}','{Vi}','{Ve,Vi}','{Se,Ve,Vi}','location','northeastoutside');

set(gca, 'XTickLabel', {'1','2','3','4','5','6','7','8','9','10','11','12'});
set(gca,'FontName','Times New Roman','FontSize',30);
  xlabel('{CM}_{f_{l}}(l=1,...,12)');
  yyaxis left
 ylabel('Combined result');
hold on
grid on
 yyaxis right
 ylabel('Complex similarity measure');
 p = plot(x,yy,'-k*','LineWidth',1.5);
  h1=legend('{Ve}','{Vi}','{Ve,Vi}','{Se,Ve,Vi}','CSM_{D}');
     
     set(h1,'FontName','Times New Roman','FontSize',15);
