


y=[      0         0    0.4052         0         0    0.3555    0.2393
         0         0    0.6640         0         0    0.2692    0.0668
         0         0    0.8516         0         0    0.1484         0
         0    0.1172    0.7518         0         0    0.1310         0
         0    0.2773    0.6155         0         0    0.1073         0
         0    0.4615    0.4586         0         0    0.0799         0
         0    0.6434    0.3037         0         0    0.0529         0
         0    0.7887    0.1800         0         0    0.0314         0
         0         0    1.0000         0         0         0         0
         0         0    1.0000         0         0         0         0
         0         0    1.0000         0         0         0         0
         0         0    1.0000         0         0         0         0
];
yy=[1 0.9964    0.9808    0.2992    0.4102    0.5800    0.7585    0.8570    0.2320    1.0000    0.2071    0.1746];
x=[1 2 3 4 5 6 7 8 9 10 11 12];
    b=bar(x,y,1.0);

 hold on
legend([b],'{Se}','{Ve}','{Vi}','{Se,Ve}','{Se,Vi}','{Ve,Vi}','{Se,Ve,Vi}','location','northeastoutside');

set(gca, 'XTickLabel', {'1','2','3','4','5','6','7','8','9','10','11','12'});
set(gca,'FontName','Times New Roman','FontSize',30);
  xlabel('{CM}_{f_{l}}(l=1,...,12)');
  yyaxis left
 ylabel('Combined result');
hold on
grid on
 yyaxis right
 ylabel('Complex similarity measure');
 p = plot(x,yy,'-k*','LineWidth',1.5);
  h1=legend('{Se}','{Ve}','{Vi}','{Se,Ve}','{Se,Vi}','{Ve,Vi}','{Se,Ve,Vi}','CSM_{D}');
     
     set(h1,'FontName','Times New Roman','FontSize',15);

