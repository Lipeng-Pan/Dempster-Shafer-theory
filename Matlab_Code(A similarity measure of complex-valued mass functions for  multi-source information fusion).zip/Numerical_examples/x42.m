function []=x42()
t=0:0.05:0.5*pi;
p=0:0.05:1;
[theta,phi]=meshgrid(t,p);
Ax1=phi.*cos(theta);
Ay1=phi.*sin(theta);

Xx1=(1-phi).*cos(theta);
Xy1=(1-phi).*sin(theta);

Ax2=(1-phi).*cos(-theta);
Ay2=(1-phi).*sin(-theta);

Xx2=phi.*cos(-theta);
Xy2=phi.*sin(-theta);

m1A=Ax1+i.*Ay1;
m1X=Xx1+i.*Xy1;

m2A=Ax2+i.*Ay2;
m2X=Xx2+i.*Xy2;

 S1=(((m1A+m1X./3).*conj(m2A)+(m1A./3+m1X./3).*conj(m2X)))./((((m1A+m1X./3).*conj(m1A)+(m1A./3+m1X./3).*conj(m1X))).^0.5.*(((m2A+m2X./3).*conj(m2A)+(m2A./3+m2X./3).*conj(m2X))).^0.5);

Sim1=(S1.*conj(S1)).^0.5;
   mesh(Ax1,Ay1,Sim1);
 x1=xlabel('x');       
 x2=ylabel('y');        
 x3=zlabel('CSM'); 
 h = colorbar;
set(get(h,'label'),'string')
set(gca,'FontName','Times New Roman','FontSize',30);

hold on

  S2=(((m1A+m1X./2).*conj(m2A)+(m1A./2+m1X./2).*conj(m2X)))./(((m1A+m1X./2).*conj(m1A)+(m1A./2+m1X./2).*conj(m1X)).^0.5.*((m2A+m2X./2).*conj(m2A)+(m2A./2+m2X./2).*conj(m2X)).^0.5);
% 
 Sim2=(S2.*conj(S2)).^0.5;
 mesh(Ax1,Ay1,Sim2);
 
   h1=text(0,0,0.5574,'D_{2}');
   h2=text(0.99,0,0.7177,'D_{1}')
   set(h1,'FontName','Times New Roman','FontSize',15);
   set(h2,'FontName','Times New Roman','FontSize',15);
end
   
   
   