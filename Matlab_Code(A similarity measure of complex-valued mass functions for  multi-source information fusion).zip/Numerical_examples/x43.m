function []=x43()
t=0:0.05:0.5*pi;
p=0:0.05:1;
[theta,phi]=meshgrid(t,p);
Ax1=phi.*cos(theta);
Ay1=phi.*sin(theta);

Bx1=(1-phi)./2.*cos(theta);
By1=(1-phi)./2.*cos(theta);


Xx1=(1-phi)./2.*cos(theta);
Xy1=(1-phi)./2.*sin(theta);

Ax2=(1-phi)./2.*cos(-theta);
Ay2=(1-phi)./2.*sin(-theta);

Bx2=phi.*cos(-theta);
By2=phi.*cos(-theta);

Xx2=(1-phi)./2.*cos(-theta);
Xy2=(1-phi)./2.*sin(-theta);

m1A=Ax1+i.*Ay1;
m1B=Bx1+i.*By1;
m1X=Xx1+i.*Xy1;

m2A=Ax2+i.*Ay2;
m2B=Bx2+i.*By2;
m2X=Xx2+i.*Xy2;


S1=((m1A+m1X./3).*conj(m2A)+(m1B+m1X./3).*conj(m2B)+(m1A./3+m1B./3+m1X).*conj(m2X))./ (((m1A+m1X./3).*conj(m1A)+(m1B+m1X./3).*conj(m1B)+(m1A./3+m1B./3+m1X).*conj(m1X)).^0.5.*((m2A+m2X./3).*conj(m2A)+(m2B+m2X./3).*conj(m2B)+(m2A./3+m2B./3+m2X).*conj(m2X)).^0.5);

  Sim1=(S1.*conj(S1)).^0.5;
  mesh(Ax1,Ay1,Sim1);
  zmax=max(max(Sim1));
  [id_xmax,id_ymax]=find(Sim1==zmax);
  xmax=Ax1(id_xmax);
  ymax=Ay1(id_ymax);
  hold on
  plot3(xmax,ymax,zmax,'k.','markersize',20)
   h1=text(xmax,ymax,zmax,['x=',num2str(xmax),char(10),'y=',num2str(ymax),char(10),'CSM=',num2str(zmax)]);
   hold on 
  plot3(1,0,0,'r.','markersize',20)
  h2=text(1,0,0,['x=',num2str(1),char(10),'y=',num2str(0),char(10),'CSM=',num2str(0)]);
     set(h1,'FontName','Times New Roman','FontSize',15);
   set(h2,'FontName','Times New Roman','FontSize',15);
  
 x1=xlabel('x_{1}');       
 x2=ylabel('y_{1}');        
 x3=zlabel('CSM'); 
 h = colorbar;
set(get(h,'label'),'string')
set(gca,'FontName','Times New Roman','FontSize',30);
grid on
hold on
end
