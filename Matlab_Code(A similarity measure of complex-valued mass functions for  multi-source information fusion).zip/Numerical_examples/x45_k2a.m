function []=x45_k2a()

[x,y] = meshgrid(0:0.02:1);

z = 1-(x.^2+y.^2).^0.5;

L = z<0;

x(L) = nan;

y(L) = nan;

z(L) = nan;




S=x.^2+y.^2;

mesh(x,y,S);


 x1=xlabel('x');       
 x2=ylabel('y');        
 x3=zlabel('CSM'); 
 h = colorbar;
set(get(h,'label'),'string')
set(gca,'FontName','Times New Roman','FontSize',30);
hold on
end

