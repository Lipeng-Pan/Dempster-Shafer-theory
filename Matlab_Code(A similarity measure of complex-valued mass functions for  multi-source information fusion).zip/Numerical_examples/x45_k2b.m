function []=x45_k2b()
[x,y] = meshgrid(0:0.02:1);

z = 1-(x.^2+y.^2).^0.5;

L = z<0;

x(L) = nan;

y(L) = nan;

z(L) = nan;

r1=x.^0.5;
i1=y.^0.5;


r2=(2/3*z.^2).^0.5;
i2=(1/3*z.^2).^0.5;


m1A=r1+i*i1;
m1B=r2-i*i2;

m2A=r2+i*i2;
m2B=r1-i*i1;

m2A=r2+i*i2;
m2AB=r1-i*i1;



S=abs(m1A.*conj(m2A)+m1B.*conj(m2B))./((m1A.*conj(m1A)+m1B.*conj(m1B)).^0.5.*(m2A.*conj(m2A)+m2B.*conj(m2B)).^0.5);
S=abs(S);




meshc(x,y,S);


 x1=xlabel('x');       
 x2=ylabel('y');        
 x3=zlabel('CSM'); 
 h = colorbar;
set(get(h,'label'),'string')
set(gca,'FontName','Times New Roman','FontSize',30);
end