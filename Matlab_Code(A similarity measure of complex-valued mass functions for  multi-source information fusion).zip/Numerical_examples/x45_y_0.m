function []=x45_y_0()

[x,y] = meshgrid(0:0.05:1);

y(:,:)=0;
z = 1-x-y;

L = z<0;

x(L) = nan;


z(L) = nan;

r1=x.^0.5;
i1=y.^0.5;

r2=(2/3*z).^0.5;
i2=(1/2*z).^0.5;



m1A=abs(r1+i*i1);
m1B=abs(r2+i*i2);

m2A=abs(r2+i*i2);
m2B=abs(r1+i*i1);

m2A=abs(r2+i*i2);
m2AB=abs(r1+i*i1);


S21=abs(m1A.*conj(m2A)+m1B.*conj(m2B))./((m1A.*conj(m1A)+m1B.*conj(m1B)).^0.5.*(m2A.*conj(m2A)+m2B.*conj(m2B)).^0.5);
S21=abs(S21);
mesh(x,y,S21);
view(0,0)
hold on




S11=abs(m1A.*conj(m2A)+m1B.*conj(m2B))./((m1A.*conj(m1A)+m1B.*conj(m1B)).^0.5.*(m2A.*conj(m2A)+m2B.*conj(m2B)).^0.5);
S11=abs(S11);
mesh(x,y,S11);
view(0,0);
hold on




S22=abs(m1A.*conj(m2A)+(m1A+m1B)./3.*conj(m2AB))./((m1A.*conj(m1A)+m1B.*conj(m1B)).^0.5.*((m2A+m2AB./3).*conj(m2A)+(m2A./3+m2AB).*conj(m2AB)).^0.5);
S22=abs(S22);
mesh(x,y,S22);
view(0,0);
hold on

S12=abs(m1A.*conj(m2A)+(m1A+m1B)./2.*conj(m2AB))./((m1A.*conj(m1A)+m1B.*conj(m1B)).^0.5.*((m2A+m2AB./2).*conj(m2A)+(m2A./2+m2AB).*conj(m2AB)).^0.5);
S12=abs(S12);
mesh(x,y,S12);
view(0,0);


x1=xlabel('x');       
x2=ylabel('y');        
x3=zlabel('Vaule'); 
h = colorbar;
set(get(h,'label'),'string')

  h1=text(0.1,0.2,0.8964,'Jiang^{,} method:X_{\kappa}={\kappa _{1}} ');
  h2=text(0.93,0.2,0.3982,'CSM:X_{\kappa}={\kappa _{1}}');
  h3=text(0.4,0.2,0.6968,'Jiang^{,} method:X_{\kappa}={\kappa _{1},\kappa _{2}} ');
  h4=text(0.4,0.2,0.8007,'CSM:X_{\kappa}={\kappa _{1},\kappa _{2}}');
  
    set(h1,'FontName','Times New Roman','FontSize',15);
   set(h2,'FontName','Times New Roman','FontSize',15);
   set(h3,'FontName','Times New Roman','FontSize',15);
   set(h4,'FontName','Times New Roman','FontSize',15);

 set(gca,'FontName','Times New Roman','FontSize',30);
end

