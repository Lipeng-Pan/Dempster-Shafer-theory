DataO=xlsread('C:\Users\Li_Peng_Pan\Desktop\INS-D-22-5070\CSE_INS\INS_matlab\application\IRIS_CET\rationumber_Iris.csv');

M1=DataO;

 
 
x=0.1:0.02:0.9;
h1=plot(x,M1(1,:),'--r',x,M1(2,:),'--.g',x,M1(3,:),'--xg',x,M1(4,:),'--vg',x,M1(5,:),'--og',x,M1(6,:),'--dg',x,M1(9,:),'--<b',x,M1(10,:),'-->b','LineWidth',1);
lgd1=legend([h1],'Accuracy(\delta=0)','Accuracy(\delta=1-\tau )','Accuracy(\delta=1-2\tau ).','Accuracy(\delta=1-3\tau )','Accuracy(\delta=1-4\tau )','Accuracy(\delta=1-5\tau )','Accuracy(Xiao^{,} work^{1})','Accuracy(Xiao^{,} work^{2})','orientation','horizontal','location','north');
set(lgd1,'FontName','Times New Roman','FontSize',15);
% axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% ah=axes('position',get(gca,'position'),'visible','off');
ylabel('The target recognition rate');
xlabel('Percentage of training sets ');
set(gca,'FontName','Times New Roman','FontSize',30);




figure


DataO=xlsread('C:\Users\Li_Peng_Pan\Desktop\INS-D-22-5070\CSE_INS\INS_matlab\application\Newfertility_Diagnosis_CET\rationumber_FD.csv');

M1=DataO;

% N1=5;
% N2=45;
 
 
x=0.26:0.08:0.82;

h1=plot(x,M1(1,:),'--r',x,M1(2,:),'--.g',x,M1(3,:),'--xg',x,M1(4,:),'--vg',x,M1(5,:),'--og',x,M1(6,:),'--dg',x,M1(9,:),'--<b',x,M1(10,:),'-->b','LineWidth',1);
lgd1=legend([h1],'Accuracy(\delta=0)','Accuracy(\delta=1-\tau )','Accuracy(\delta=1-2\tau ).','Accuracy(\delta=1-3\tau )','Accuracy(\delta=1-4\tau )','Accuracy(\delta=1-5\tau )','Accuracy(Xiao^{,} work^{1})','Accuracy(Xiao^{,} work^{2})','orientation','horizontal','location','north');
set(lgd1,'FontName','Times New Roman','FontSize',15);
% axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% ah=axes('position',get(gca,'position'),'visible','off');
ylabel('The target recognition rate');
xlabel('Percentage of training sets ');
set(gca,'FontName','Times New Roman','FontSize',30);


figure

DataO=xlsread('C:\Users\Li_Peng_Pan\Desktop\INS-D-22-5070\CSE_INS\INS_matlab\application\BTSC_CET\rationumber_BTSC.csv');

M1=DataO;

% N1=5;
% N2=45;
 
 
x=0.0642:0.0107:0.8988;

h1=plot(x,M1(1,:),'--r',x,M1(2,:),'--.g',x,M1(3,:),'--xg',x,M1(4,:),'--vg',x,M1(5,:),'--og',x,M1(6,:),'--dg',x,M1(9,:),'--<b',x,M1(10,:),'-->b','LineWidth',1);
lgd1=legend([h1],'Accuracy(\delta=0)','Accuracy(\delta=1-\tau )','Accuracy(\delta=1-2\tau ).','Accuracy(\delta=1-3\tau )','Accuracy(\delta=1-4\tau )','Accuracy(\delta=1-5\tau )','Accuracy(Xiao^{,} work^{1})','Accuracy(Xiao^{,} work^{2})','orientation','horizontal','location','north');
set(lgd1,'FontName','Times New Roman','FontSize',15);
% axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% ah=axes('position',get(gca,'position'),'visible','off');
ylabel('The target recognition rate');
xlabel('Percentage of training sets ');
set(gca,'FontName','Times New Roman','FontSize',30);


figure


DataO=xlsread('C:\Users\Li_Peng_Pan\Desktop\INS-D-22-5070\CSE_INS\INS_matlab\application\Climate Model Simulation Crashes_CET\rationumber_CMSC.csv');

M1=DataO;

% N1=5;
% N2=45;
 
 
x=0.1019:0.0198:0.8358;


h1=plot(x,M1(1,:),'--r',x,M1(2,:),'--.g',x,M1(3,:),'--xg',x,M1(4,:),'--vg',x,M1(5,:),'--og',x,M1(6,:),'--dg',x,M1(9,:),'--<b',x,M1(10,:),'-->b','LineWidth',1);
lgd1=legend([h1],'Accuracy(\delta=0)','Accuracy(\delta=1-\tau )','Accuracy(\delta=1-2\tau ).','Accuracy(\delta=1-3\tau )','Accuracy(\delta=1-4\tau )','Accuracy(\delta=1-5\tau )','Accuracy(Xiao^{,} work^{1})','Accuracy(Xiao^{,} work^{2})','orientation','horizontal','location','north');
set(lgd1,'FontName','Times New Roman','FontSize',15);
% axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% ah=axes('position',get(gca,'position'),'visible','off');
ylabel('The target recognition rate');
xlabel('Percentage of training sets ');
set(gca,'FontName','Times New Roman','FontSize',30);













% DataO=xlsread('C:\Users\panlipeng\Desktop\ESWA-D-21-04938\daima\application\SPECT\rationumber.xlsx');
% 
% M1=DataO;
% 
% % N1=5;
% % N2=45;
%  
%  
% x=0.1250:0.025:0.9250;
% h1=plot(x,M1(2,:),'--*g',x,M1(3,:),'--.b',x,M1(4,:),'--xc',x,M1(5,:),'--vr',x,M1(1,:),'--ok','LineWidth',1);
% lgd1=legend([h1],'The results based on the  method of Dempster','The results based on the  method of Murphy','The results based on the  method of Deng et al.','The results based on the  method of Xiao','The results based on proposed method','orientation','horizontal','location','north');
% set(lgd1,'FontName','Times New Roman','FontSize',12);
% % axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% % ah=axes('position',get(gca,'position'),'visible','off');
% ylabel('The target recognition rate');
% xlabel('Percentage of training sets ');
% set(gca,'FontName','Times New Roman','FontSize',30);
% 
% a60=M1(:,round((0.6-0.1250)/0.025))';
% a60(1)-max(a60(2:5))
% figure
% 
% DataO=xlsread('C:\Users\panlipeng\Desktop\ESWA-D-21-04938\daima\application\Flowmeters\Flowmeters\rationumber.xlsx');
% 
% M1=DataO;
% 
% % N1=5;
% % N2=45;
%  
%  
% x=0.2529:0.0221:0.8046;
% h1=plot(x,M1(2,:),'--*g',x,M1(3,:),'--.b',x,M1(4,:),'--xc',x,M1(5,:),'--vr',x,M1(1,:),'--ok','LineWidth',1);
% lgd1=legend([h1],'The results based on the  method of Dempster','The results based on the  method of Murphy','The results based on the  method of Deng et al.','The results based on the  method of Xiao','The results based on proposed method','orientation','horizontal','location','north');
% set(lgd1,'FontName','Times New Roman','FontSize',12);
% % axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% % ah=axes('position',get(gca,'position'),'visible','off');
% ylabel('The target recognition rate');
% xlabel('Percentage of training sets ');
% set(gca,'FontName','Times New Roman','FontSize',30);
% 
% a60=M1(:,round((0.6-0.2529)/0.0221))';
% a60(1)-max(a60(2:5))
% figure 
% 
% DataO=xlsread('C:\Users\panlipeng\Desktop\ESWA-D-21-04938\daima\application\sonar\rationumber.xlsx');
% 
% M1=DataO;
% 
% % N1=5;
% % N2=45;
%  
%  
% x=0.1106:0.0192:0.8606;
% h1=plot(x,M1(2,:),'--*g',x,M1(3,:),'--.b',x,M1(4,:),'--xc',x,M1(5,:),'--vr',x,M1(1,:),'--ok','LineWidth',1);
% lgd1=legend([h1],'The results based on the  method of Dempster','The results based on the  method of Murphy','The results based on the  method of Deng et al.','The results based on the  method of Xiao','The results based on proposed method','orientation','horizontal','location','north');
% set(lgd1,'FontName','Times New Roman','FontSize',12);
% % axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% % ah=axes('position',get(gca,'position'),'visible','off');
% ylabel('The target recognition rate');
% xlabel('Percentage of training sets ');
% set(gca,'FontName','Times New Roman','FontSize',30);
% 
% a60=M1(:,round((0.6-0.1106)/0.0192))';
% a60(1)-max(a60(2:5))
% figure 
% 
% DataO=xlsread('C:\Users\panlipeng\Desktop\ESWA-D-21-04938\daima\application\seeds\rationumber2.xlsx');
% 
% M1=DataO;
% 
% % N1=5;
% % N2=45;
%  
%  
% x=0.1:0.0143:0.9008;
% h1=plot(x,M1(2,:),'--*g',x,M1(3,:),'--.b',x,M1(4,:),'--xc',x,M1(5,:),'--vr',x,M1(1,:),'--ok','LineWidth',1);
% lgd1=legend([h1],'The results based on the  method of Dempster','The results based on the  method of Murphy','The results based on the  method of Deng et al.','The results based on the  method of Xiao','The results based on proposed method','orientation','horizontal','location','north');
% set(lgd1,'FontName','Times New Roman','FontSize',12);
% % axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% % ah=axes('position',get(gca,'position'),'visible','off');
% ylabel('The target recognition rate');
% xlabel('Percentage of training sets ');
% set(gca,'FontName','Times New Roman','FontSize',30);
% 
% 
% a60=M1(:,round((0.6-0.1)/0.0143))';
% a60(1)-max(a60(2:5))
% 
% figure
% 
% DataO=xlsread('C:\Users\panlipeng\Desktop\ESWA-D-21-04938\daima\application\Newfertility_Diagnosis\rationumber.xlsx');
% 
% M1=DataO;
% 
% % N1=5;
% % N2=45;
%  
%  
% x=0.26:0.08:0.82;
% h1=plot(x,M1(2,:),'--*g',x,M1(3,:),'--.b',x,M1(4,:),'--xc',x,M1(5,:),'--vr',x,M1(1,:),'--ok','LineWidth',1);
% lgd1=legend([h1],'The results based on the  method of Dempster','The results based on the  method of Murphy','The results based on the  method of Deng et al.','The results based on the  method of Xiao','The results based on proposed method','orientation','horizontal','location','north');
% set(lgd1,'FontName','Times New Roman','FontSize',12);
% % axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% % ah=axes('position',get(gca,'position'),'visible','off');
% ylabel('The target recognition rate');
% xlabel('Percentage of training sets ');
% set(gca,'FontName','Times New Roman','FontSize',30);
% 
% a60=M1(:,round((0.6-0.26)/0.08))';
% a60(1)-max(a60(2:5))
% figure 
% 
% DataO=xlsread('C:\Users\panlipeng\Desktop\ESWA-D-21-04938\daima\application\NEWtransfusion\rationumber.xlsx');
% 
% M1=DataO;
% 
% % N1=5;
% % N2=45;
%  
%  
% x=0.0642:0.0107:0.8988;
% h1=plot(x,M1(2,:),'--*g',x,M1(3,:),'--.b',x,M1(4,:),'--xc',x,M1(5,:),'--vr',x,M1(1,:),'--ok','LineWidth',1);
% lgd1=legend([h1],'The results based on the  method of Dempster','The results based on the  method of Murphy','The results based on the  method of Deng et al.','The results based on the  method of Xiao','The results based on proposed method','orientation','horizontal','location','north');
% set(lgd1,'FontName','Times New Roman','FontSize',12);
% % axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% % ah=axes('position',get(gca,'position'),'visible','off');
% ylabel('The target recognition rate');
% xlabel('Percentage of training sets ');
% set(gca,'FontName','Times New Roman','FontSize',30);
% 
% 
% a60=M1(:,round((0.6-0.0642)/0.0107))';
% a60(1)-max(a60(2:5))
% figure

% DataO=xlsread('C:\Users\panlipeng\Desktop\ESWA-D-21-04938\daima\application\Climate Model Simulation Crashes\rationumber.xlsx');
% 
% M1=DataO;

% N1=5;
% N2=45;
 
 
% x=0.1019:0.0198:0.8358;
% h1=plot(x,M1(2,:),'--*g',x,M1(3,:),'--.b',x,M1(4,:),'--xc',x,M1(5,:),'--vr',x,M1(1,:),'--ok','LineWidth',1);
% lgd1=legend([h1],'The results based on the  method of Dempster','The results based on the  method of Murphy','The results based on the  method of Deng et al.','The results based on the  method of Xiao','The results based on proposed method','orientation','horizontal','location','north');
% set(lgd1,'FontName','Times New Roman','FontSize',12);
% % axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% % ah=axes('position',get(gca,'position'),'visible','off');
% ylabel('The target recognition rate');
% xlabel('Percentage of training sets ');
% set(gca,'FontName','Times New Roman','FontSize',30);
% 
% 
% a60=M1(:,round((0.6-0.1019)/0.0198))';
% a60(1)-max(a60(2:5))
% 
% figure
% 
% DataO=xlsread('C:\Users\panlipeng\Desktop\ESWA-D-21-04938\daima\application\breast-cancer\rationumber.xlsx');
% 
% M1=DataO;
% 
% N1=5;
% N2=45;
%  
%  
% x=0.0958:0.0129:0.9085;
% h1=plot(x,M1(2,:),'--*g',x,M1(3,:),'--.b',x,M1(4,:),'--xc',x,M1(5,:),'--vr',x,M1(1,:),'--ok','LineWidth',1);
% lgd1=legend([h1],'The results based on the  method of Dempster','The results based on the  method of Murphy','The results based on the  method of Deng et al.','The results based on the  method of Xiao','The results based on proposed method','orientation','horizontal','location','north');
% set(lgd1,'FontName','Times New Roman','FontSize',12);
% % axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% % ah=axes('position',get(gca,'position'),'visible','off');
% ylabel('The target recognition rate');
% xlabel('Percentage of training sets ');
% set(gca,'FontName','Times New Roman','FontSize',30);
% 
% 
% a60=M1(:,round((0.6-0.0958)/0.0129))';
% a60(1)-max(a60(2:5))