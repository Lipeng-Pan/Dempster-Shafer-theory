DataO=xlsread('C:\Users\Li_Peng_Pan\Desktop\INS-D-22-5070\CSE_INS\INS_matlab\application\IRIS_CET\ratio_Knumber_Iris.csv');

M1=1-DataO;

 
 
x=0.1:0.02:0.9;
h1=plot(x,M1(1,:),'--r',x,M1(2,:),'--.g',x,M1(3,:),'--xb',x,M1(4,:),'--vc',x,M1(5,:),'--om','LineWidth',1);
lgd1=legend([h1],'\delta=1-\tau','\delta=1-2\tau .','\delta=1-3\tau ','\delta=1-4\tau ','\delta=1-5\tau','orientation','horizontal','location','north');
set(lgd1,'FontName','Times New Roman','FontSize',15);
% axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% ah=axes('position',get(gca,'position'),'visible','off');
ylabel(' R_{t}');
xlabel('Percentage of training sets ');
set(gca,'FontName','Times New Roman','FontSize',30);




figure


DataO=xlsread('C:\Users\Li_Peng_Pan\Desktop\INS-D-22-5070\CSE_INS\INS_matlab\application\Newfertility_Diagnosis_CET\ratio_Knumber_FD.csv');

M1=1-DataO;

% N1=5;
% N2=45;
 
 
x=0.26:0.08:0.82;

h1=plot(x,M1(1,:),'--r',x,M1(2,:),'--.g',x,M1(3,:),'--xb',x,M1(4,:),'--vc',x,M1(5,:),'--om','LineWidth',1);
lgd1=legend([h1],'\delta=1-\tau','\delta=1-2\tau .','\delta=1-3\tau ','\delta=1-4\tau ','\delta=1-5\tau','orientation','horizontal','location','north');
set(lgd1,'FontName','Times New Roman','FontSize',15);
% axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% ah=axes('position',get(gca,'position'),'visible','off');
ylabel(' R_{t}');
xlabel('Percentage of training sets ');
set(gca,'FontName','Times New Roman','FontSize',30);


figure

DataO=xlsread('C:\Users\Li_Peng_Pan\Desktop\INS-D-22-5070\CSE_INS\INS_matlab\application\BTSC_CET\ratio_Knumber_BTSC.csv');

M1=1-DataO;

% N1=5;
% N2=45;
 
 
x=0.0642:0.0107:0.8988;

h1=plot(x,M1(1,:),'--r',x,M1(2,:),'--.g',x,M1(3,:),'--xb',x,M1(4,:),'--vc',x,M1(5,:),'--om','LineWidth',1);
lgd1=legend([h1],'\delta=1-\tau','\delta=1-2\tau .','\delta=1-3\tau ','\delta=1-4\tau ','\delta=1-5\tau','orientation','horizontal','location','north');
set(lgd1,'FontName','Times New Roman','FontSize',15);
% axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% ah=axes('position',get(gca,'position'),'visible','off');
ylabel(' R_{t}');
xlabel('Percentage of training sets ');
set(gca,'FontName','Times New Roman','FontSize',30);


figure


DataO=xlsread('C:\Users\Li_Peng_Pan\Desktop\INS-D-22-5070\CSE_INS\INS_matlab\application\Climate Model Simulation Crashes_CET\ratio_Knumber_CMSC.csv');

M1=1-DataO;

% N1=5;
% N2=45;
 
 
x=0.1019:0.0198:0.8358;


h1=plot(x,M1(1,:),'--r',x,M1(2,:),'--.g',x,M1(3,:),'--xb',x,M1(4,:),'--vc',x,M1(5,:),'--om','LineWidth',1);
lgd1=legend([h1],'\delta=1-\tau','\delta=1-2\tau .','\delta=1-3\tau ','\delta=1-4\tau ','\delta=1-5\tau','orientation','horizontal','location','north');
set(lgd1,'FontName','Times New Roman','FontSize',15);
% axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% ah=axes('position',get(gca,'position'),'visible','off');
ylabel(' R_{t}');
xlabel('Percentage of training sets ');
set(gca,'FontName','Times New Roman','FontSize',30);








% DataO=xlsread('C:\Users\panlipeng\Desktop\ESWA-D-21-04938\daima\application\Climate Model Simulation Crashes\rationumber.xlsx');
% 
% M1=DataO;
% 
% % N1=5;
% % N2=45;
%  
%  
% x=0.1019:0.0198:0.8358;
% h1=plot(x,M1(2,:),'--*g',x,M1(3,:),'--.b',x,M1(4,:),'--xc',x,M1(5,:),'--vr',x,M1(1,:),'--ok','LineWidth',1);
% lgd1=legend([h1],'The results based on the  method of Dempster','The results based on the  method of Murphy','The results based on the  method of Deng et al.','The results based on the  method of Xiao','The results based on proposed method','orientation','horizontal','location','north');
% set(lgd1,'FontName','Times New Roman','FontSize',12);
% % axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% % ah=axes('position',get(gca,'position'),'visible','off');
% ylabel('The target recognition rate');
% xlabel('Percentage of training sets ');
% set(gca,'FontName','Times New Roman','FontSize',30);
% 
% 
% a60=M1(:,round((0.6-0.1019)/0.0198))';
% a60(1)-max(a60(2:5))
% 
% figure
% 
% DataO=xlsread('C:\Users\panlipeng\Desktop\ESWA-D-21-04938\daima\application\breast-cancer\rationumber.xlsx');
% 
% M1=DataO;
% 
% N1=5;
% N2=45;
%  
%  
% x=0.0958:0.0129:0.9085;
% h1=plot(x,M1(2,:),'--*g',x,M1(3,:),'--.b',x,M1(4,:),'--xc',x,M1(5,:),'--vr',x,M1(1,:),'--ok','LineWidth',1);
% lgd1=legend([h1],'The results based on the  method of Dempster','The results based on the  method of Murphy','The results based on the  method of Deng et al.','The results based on the  method of Xiao','The results based on proposed method','orientation','horizontal','location','north');
% set(lgd1,'FontName','Times New Roman','FontSize',12);
% % axis([5 45 min(min(M1))-0.01 max(max(M1))]);
% % ah=axes('position',get(gca,'position'),'visible','off');
% ylabel('The target recognition rate');
% xlabel('Percentage of training sets ');
% set(gca,'FontName','Times New Roman','FontSize',30);
% 
% 
% a60=M1(:,round((0.6-0.0958)/0.0129))';
% a60(1)-max(a60(2:5))