function [S_vaule]=CSM(m1,m2)

D= [1 0 1/3 
      0 1  1/3 
      1/3 1/3 1];

S_vaule_1=m1*D*m2'/(m1*D*m1'*m2*D*m2').^0.5;

S_vaule=S_vaule_1*S_vaule_1';
end