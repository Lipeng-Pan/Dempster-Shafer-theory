clc
clear all

D=[1 0 0.5
   0 1 0.5
   0.5 0.5 1];

DD=D;

X=[1 0 0
   0 1 0]; 

NN=3;

Number=1000;

DataO=xlsread('C:\Users\Li_Peng_Pan\Desktop\INS-D-22-5070\CSE_INS\INS_matlab\application\Newfertility_Diagnosis_CET\Newfertility_Diagnosis.xlsx');

[c,r]=size(DataO); 

 Data=DataO(:,2:r); 
 
 SE=Data(1:88,:);
 VE=Data(89:100,:);
 
NSE=88;
NVE=12;

 
 

rationumber=zeros(10,8);
ratio_Knumber=zeros(5,8);

for kkk=1:1:8 
    kkk
    N1=16+7*(kkk);
    N2=2+(kkk);
    
     (N1+N2)/(NSE+NVE)
     
ratio1=zeros(1,Number);
ratio2=zeros(1,Number);
ratio3=zeros(1,Number);
ratio4=zeros(1,Number);
ratio5=zeros(1,Number);
ratio6=zeros(1,Number);
ratio7=zeros(1,Number);
ratio8=zeros(1,Number);
ratio9=zeros(1,Number);
ratio10=zeros(1,Number);

Kumber1=ones(Number,c-N1-N2);
Kumber2=ones(Number,c-N1-N2);
Kumber3=ones(Number,c-N1-N2);
Kumber4=ones(Number,c-N1-N2);
Kumber5=ones(Number,c-N1-N2);




for time=1:1:Number
    
    
 randnumberse=randperm(size(SE,1));
 randnumberve=randperm(size(VE,1));
 
 SE=SE(randnumberse,:);
 VE=VE(randnumberve,:);
 
 
 SE_train=SE(1:N1,:);
 VE_train=VE(1:N2,:);
 
 
 
 SEVE_train=[SE_train;VE_train];
 
 
 Train_variation=[std(SE_train),mean(SE_train,1);std(VE_train),mean(VE_train,1);std(SEVE_train),mean(SEVE_train,1)];
 
 
  
  
  %����ѵ����
 test=[SE(N1+1:NSE,:);VE(N2+1:NVE,:)];
 
  BPA1=zeros(c-N1-N2,NN);
  BPA2=zeros(c-N1-N2,NN);
  BPA3=zeros(c-N1-N2,NN);
  BPA4=zeros(c-N1-N2,NN);
  BPA5=zeros(c-N1-N2,NN);
  BPA6=zeros(c-N1-N2,NN);
  BPA7=zeros(c-N1-N2,NN);
  BPA8=zeros(c-N1-N2,NN);
  BPA9=zeros(c-N1-N2,NN);
  BPA10=zeros(c-N1-N2,NN);
  
  
for mm=1:1:c-N1-N2

  SE_test=[SE_train;test(mm,:)];
 VE_test=[VE_train;test(mm,:)];
 
 SEVE_test=[SEVE_train;test(mm,:)];



  Test_variation=[std(SE_test),mean(SE_test,1);std(VE_test),mean(VE_test,1);std(SEVE_test),mean(SEVE_test,1)];
  
  Test_Train_R=abs(Train_variation-Test_variation);
  
   
        
Test_Train_CM=abs(Train_variation-Test_variation);

  Phase_Angle=Test_Train_CM(1:NN,r:2*(r-1));
  Phase_Angle(find(Phase_Angle>(pi/2))) =pi/2;
  Test_Train_CM(1:NN,r:2*(r-1))=Phase_Angle;
 O_CBPA1=(1./exp( abs(Test_Train_CM(1:NN,1:r-1))).*(cos(Test_Train_CM(1:NN,r:2*(r-1)))+1i*sin(Test_Train_CM(1:NN,r:2*(r-1))))).';
   
C_BPA=O_CBPA1./sum(abs(O_CBPA1),2);
OrBPA_R=abs(C_BPA);
      mp1=C_BPA(1,:);
    mp2=C_BPA(2,:);
    [outputArg1] = CDS(mp1,mp2);
    for mc=3:1:r-1
        mp1=outputArg1;
        mp2=C_BPA(mc,:);
        [outputArg1]= CDS(mp1,mp2);
    end
    BPA1(mm,:)=outputArg1;



 
    CS=zeros(r-1,r-1);
    
    for cnumber=1:1:r-1
        for rnmuber=1:1:r-1
            m1=C_BPA(cnumber,:);
            m2=C_BPA(rnmuber,:);
            [S_vaule]=CSM(m1,m2);
           CS(cnumber,rnmuber)=S_vaule;
        end
    end
    
    CS=abs(CS);
    
    CSWeight=((abs(sum(CS,2))-1)/sum((abs(sum(CS,2))-1)))';
    [B,IX]=sort(CSWeight,'descend');
    B;
    CBP=zeros(r-1,3);
    for kn=1:1:r-1
        CBP(kn,:)=C_BPA(IX(kn),:);
    end
    CBP;
    
 

 CS=abs(CS);
    
    CS_SUM=sum(CS);
    
    D_CS_SUM=std2(CS);
    

  
      m1=CBP(1,:);

      m2=CBP(1,:);
   [mp]=CDS(m1,m2);
     mp_O_1=mp;
     mp_O=mp_O_1;
    for mi=2:1:r-1
        m1=mp_O;
        m2=CBP(mi,:);
        [S_vaule]=CSM(m1,m2);
        
        CCS=abs(S_vaule);
        if (CCS>=(1-1*D_CS_SUM))
            [mp]=CDS(m1,m2);
            Kumber1(time,mm)=Kumber1(time,mm)+1;
        else
            break;
        end
        mp_O=mp;
    end
    mp;
    
    BPA2(mm,:)=mp;

    
    
 
     mp_O=mp_O_1;
    for mi=2:1:r-1
        m1=mp_O;
        m2=CBP(mi,:);
        [S_vaule]=CSM(m1,m2);
        
        CCS=abs(S_vaule);
        if (CCS>=(1-2*D_CS_SUM))
            [mp]=CDS(m1,m2);
            Kumber2(time,mm)=Kumber2(time,mm)+1;
        else
            break;
        end
        mp_O=mp;
    end
    mp;
    
  BPA3(mm,:)=mp;   
    
   
  
  
  
  
  
     mp_O=mp_O_1;
    for mi=2:1:r-1
        m1=mp_O;
        m2=CBP(mi,:);
        [S_vaule]=CSM(m1,m2);
        
        CCS=abs(S_vaule);
        if (CCS>=(1-3*D_CS_SUM))
            [mp]=CDS(m1,m2);
            Kumber3(time,mm)=Kumber3(time,mm)+1;
        else
            break;
        end
        mp_O=mp;
    end
    mp;
     
    
    BPA4(mm,:)=mp;    
    
    
    
    
 
    
     mp_O=mp_O_1;
    for mi=2:1:r-1
        m1=mp_O;
        m2=CBP(mi,:);
        [S_vaule]=CSM(m1,m2);
        
        CCS=abs(S_vaule);
        if (CCS>=(1-4*D_CS_SUM))
            [mp]=CDS(m1,m2);
            Kumber4(time,mm)=Kumber4(time,mm)+1;
        else
            break;
        end
        mp_O=mp;
    end
    mp;
      
BPA5(mm,:)=mp;
       
    
    


         
     mp_O=mp_O_1;
    for mi=2:1:r-1
        m1=mp_O;
        m2=CBP(mi,:);
        [S_vaule]=CSM(m1,m2);
        
        CCS=abs(S_vaule);
        if (CCS>=(1-5*D_CS_SUM))
            [mp]=CDS(m1,m2);
            Kumber5(time,mm)=Kumber5(time,mm)+1;
        else
            break;
        end
        mp_O=mp;
    end
    mp;
             
BPA6(mm,:)=mp;



     
     
     
      mp1=OrBPA_R(1,:);
   mp2=OrBPA_R(2,:);
     [outputArg1]=DS(mp1,mp2);
     for mmk=3:1:r-1
         mp1=outputArg1;
         mp2=OrBPA_R(mmk,:);
         [outputArg1]=DS(mp1,mp2);
     end
   outputArg1;
     
     
   BPA7(mm,:)=outputArg1;
   

   
     MBPA=sum(OrBPA_R)/(r-1);
     
     
     mp1=MBPA;
     mp2=MBPA;
     [outputArg1]=DS(mp1,mp2);
     for mmk=3:1:r-1
         mp1=outputArg1;
         mp2=MBPA;
         [outputArg1]=DS(mp1,mp2);
     end
   outputArg1;
     
     
   BPA8(mm,:)=outputArg1;
   
 

   
        CS_R=zeros(r-1,r-1);
    
    for cnumber=1:1:r-1
        for rnmuber=1:1:r-1
            m1=OrBPA_R(cnumber,:);
            m2=OrBPA_R(rnmuber,:);
            [S_vaule]=CSM(m1,m2);
           CS_R(cnumber,rnmuber)=S_vaule;
        end
    end
    
    
    CS_R_Weight_INS_Xiao=((1./(sum(1-CS_R,2)/(r-1)))/sum(1./(sum(1-CS_R,2)/(r-1))));
   
   
   Xiao_INS_BPA=sum(CS_R_Weight_INS_Xiao.*OrBPA_R);
   Xiao_INS_BPA=Xiao_INS_BPA/(sum(abs(Xiao_INS_BPA)));
   
   mp1=Xiao_INS_BPA;
   mp2=Xiao_INS_BPA;
     [outputArg1]=CDS(mp1,mp2);
     for mmk=3:1:r-1
         mp1=outputArg1;
         mp2=Xiao_INS_BPA;
         [outputArg1]=CDS(mp1,mp2);
     end
   outputArg1;
     
     
   BPA9(mm,:)=outputArg1;
   
   
   
   
   
   
   CS_R_Weight_TFS_Xiao=(sum(CS_R,2)-1)/sum(sum(CS_R,2)-1);
   
   
   
   
   
   XIao_TFS_BPA=sum(CS_R_Weight_TFS_Xiao.*OrBPA_R);
   XIao_TFS_BPA=XIao_TFS_BPA/(sum(abs(XIao_TFS_BPA)));
  
   mp1=XIao_TFS_BPA;
   mp2=XIao_TFS_BPA;
     [outputArg1]=CDS(mp1,mp2);
     for mmk=3:1:r-1
         mp1=outputArg1;
         mp2=XIao_TFS_BPA;
         [outputArg1]=CDS(mp1,mp2);
     end
   outputArg1;
     
     
   BPA10(mm,:)=outputArg1;
 
end

 

 PPT1=zeros(c-N1-N2,3);
 BPA1=abs(BPA1);
for mm=1:1:c-N1-N2
    PPT1(mm,1)=BPA1(mm,1)+BPA1(mm,3)/2;
    PPT1(mm,2)=BPA1(mm,2)+BPA1(mm,3)/2;
end
 
 [maxnum,ind]=max(PPT1,[],2);
  ind;
  
   ratioNumber1=0;
  
  for m=1:1:NSE-N1
      if (ind(m)==1)
          ratioNumber1=ratioNumber1+1;
      else
        ratioNumber1=ratioNumber1;
      end
  end
  
  for m=NSE-N1+1:1:c-N1-N2
      if (ind(m)==2)
          ratioNumber1=ratioNumber1+1;
      else
        ratioNumber1=ratioNumber1;
      end
  end
  
   
    
    
  ratio1(1,time)=ratioNumber1/(c-N1-N2);
  
 
  
  
 
PPT2=zeros(c-N1-N2,3);
BPA2=abs(BPA2);
for mm=1:1:c-N1-N2
    PPT2(mm,1)=BPA2(mm,1)+BPA2(mm,3)/2;
    PPT2(mm,2)=BPA2(mm,2)+BPA2(mm,3)/2;
end
 
 [maxnum,ind2]=max(PPT2,[],2);
  ind2;
  
   ratioNumber2=0;
  
  for m=1:1:NSE-N1
      if (ind2(m)==1)
          ratioNumber2=ratioNumber2+1;
      else
        ratioNumber2=ratioNumber2;
      end
  end
  
  for m=NSE-N1+1:1:c-N1-N2
      if (ind2(m)==2)
          ratioNumber2=ratioNumber2+1;
      else
        ratioNumber2=ratioNumber2;
      end
  end
  

    
  ratio2(1,time)=ratioNumber2/(c-N1-N2);
  
  
  
  
  
  
  PPT3=zeros(c-N1-N2,3);
  BPA3=abs(BPA3);
for mm=1:1:c-N1-N2
    PPT3(mm,1)=BPA3(mm,1)+BPA3(mm,3)/2;
    PPT3(mm,2)=BPA3(mm,2)+BPA3(mm,3)/2;
  
end
 
 [maxnum,ind]=max(PPT3,[],2);
  ind;
  
   ratioNumber3=0;
  
  for m=1:1:NSE-N1
      if (ind(m)==1)
          ratioNumber3=ratioNumber3+1;
      else
        ratioNumber3=ratioNumber3;
      end
  end
  
  for m=NSE-N1+1:1:c-N1-N2
      if (ind(m)==2)
          ratioNumber3=ratioNumber3+1;
      else
        ratioNumber3=ratioNumber3;
      end
  end
  

    
    
  ratio3(1,time)=ratioNumber3/(c-N1-N2);
  
  
  
  
  
  
  PPT4=zeros(c-N1-N2,3);
  BPA4=abs(BPA4);
for mm=1:1:c-N1-N2
    PPT4(mm,1)=BPA4(mm,1)+BPA4(mm,3)/2;
    PPT4(mm,2)=BPA4(mm,2)+BPA4(mm,3)/2;
    
end
 
 [maxnum,ind]=max(PPT4,[],2);
  ind;
  
   ratioNumber4=0;
  
  for m=1:1:NSE-N1
      if (ind(m)==1)
          ratioNumber4=ratioNumber4+1;
      else
        ratioNumber4=ratioNumber4;
      end
  end
  
  for m=NSE-N1+1:1:c-N1-N2
      if (ind(m)==2)
          ratioNumber4=ratioNumber4+1;
      else
        ratioNumber4=ratioNumber4;
      end
  end
  

    
    
  ratio4(1,time)=ratioNumber4/(c-N1-N2);
  
  
  
  
  
  
  
  
  
  PPT5=zeros(c-N1-N2,3);
  BPA5=abs(BPA5);
for mm=1:1:c-N1-N2
    PPT5(mm,1)=BPA5(mm,1)+BPA5(mm,3)/2;
    PPT5(mm,2)=BPA5(mm,2)+BPA5(mm,3)/2;
end
 
 [maxnum,ind]=max(PPT5,[],2);
  ind;
  
   ratioNumber5=0;
  
  for m=1:1:NSE-N1
      if (ind(m)==1)
          ratioNumber5=ratioNumber5+1;
      else
        ratioNumber5=ratioNumber5;
      end
  end
  
  for m=NSE-N1+1:1:c-N1-N2
      if (ind(m)==2)
          ratioNumber5=ratioNumber5+1;
      else
        ratioNumber5=ratioNumber5;
      end
  end
  

    
    
  ratio5(1,time)=ratioNumber5/(c-N1-N2);
  
  
  
  
  PPT6=zeros(c-N1-N2,3);
  BPA6=abs(BPA6);
for mm=1:1:c-N1-N2
    PPT6(mm,1)=BPA6(mm,1)+BPA6(mm,3)/2;
    PPT6(mm,2)=BPA6(mm,2)+BPA6(mm,3)/2;
end
 
 [maxnum,ind]=max(PPT6,[],2);
  ind;
  
   ratioNumber6=0;
  
  for m=1:1:NSE-N1
      if (ind(m)==1)
          ratioNumber6=ratioNumber6+1;
      else
        ratioNumber6=ratioNumber6;
      end
  end
  
  for m=NSE-N1+1:1:c-N1-N2
      if (ind(m)==2)
          ratioNumber6=ratioNumber6+1;
      else
        ratioNumber6=ratioNumber6;
      end
  end
  

    
    
  ratio6(1,time)=ratioNumber6/(c-N1-N2);
  

  
  
  PPT7=zeros(c-N1-N2,3);
for mm=1:1:c-N1-N2
    PPT7(mm,1)=BPA7(mm,1)+BPA7(mm,3)/2;
    PPT7(mm,2)=BPA7(mm,2)+BPA7(mm,3)/2;
end
 
 [maxnum,ind]=max(PPT7,[],2);
  ind;
  
   ratioNumber7=0;
  
  for m=1:1:NSE-N1
      if (ind(m)==1)
          ratioNumber7=ratioNumber7+1;
      else
        ratioNumber7=ratioNumber7;
      end
  end
  
  for m=NSE-N1+1:1:c-N1-N2
      if (ind(m)==2)
          ratioNumber7=ratioNumber7+1;
      else
        ratioNumber7=ratioNumber7;
      end
  end
  

    
    
  ratio7(1,time)=ratioNumber7/(c-N1-N2);
  
  
  

PPT8=zeros(c-N1-N2,3);
for mm=1:1:c-N1-N2
    PPT8(mm,1)=BPA8(mm,1)+BPA8(mm,3)/2;
    PPT8(mm,2)=BPA8(mm,2)+BPA8(mm,3)/2;
end
 
 [maxnum,ind]=max(PPT8,[],2);
  ind;
  
   ratioNumber8=0;
  
  for m=1:1:NSE-N1
      if (ind(m)==1)
          ratioNumber8=ratioNumber8+1;
      else
        ratioNumber8=ratioNumber8;
      end
  end
  
  for m=NSE-N1+1:1:c-N1-N2
      if (ind(m)==2)
          ratioNumber8=ratioNumber8+1;
      else
        ratioNumber8=ratioNumber8;
      end
  end
  

    
    
  ratio8(1,time)=ratioNumber8/(c-N1-N2);
  
  
  
PPT9=zeros(c-N1-N2,3);
BPA9=abs(BPA9);
for mm=1:1:c-N1-N2
    PPT9(mm,1)=BPA9(mm,1)+BPA9(mm,3)/2;
    PPT9(mm,2)=BPA9(mm,2)+BPA9(mm,3)/2;
end
 
 [maxnum,ind]=max(PPT9,[],2);
  ind;
  
   ratioNumber9=0;
  
  for m=1:1:NSE-N1
      if (ind(m)==1)
          ratioNumber9=ratioNumber9+1;
      else
        ratioNumber9=ratioNumber9;
      end
  end
  
  for m=NSE-N1+1:1:c-N1-N2
      if (ind(m)==2)
          ratioNumber9=ratioNumber9+1;
      else
        ratioNumber9=ratioNumber9;
      end
  end
  

    
    
  ratio9(1,time)=ratioNumber9/(c-N1-N2);
  
  
  PPT10=zeros(c-N1-N2,3);
  BPA10=abs(BPA10);
for mm=1:1:c-N1-N2
    PPT10(mm,1)=BPA10(mm,1)+BPA10(mm,3)/2;
    PPT10(mm,2)=BPA10(mm,2)+BPA10(mm,3)/2;
end
 
 [maxnum,ind]=max(PPT10,[],2);
  ind;
  
   ratioNumber10=0;
  
  for m=1:1:NSE-N1
      if (ind(m)==1)
          ratioNumber10=ratioNumber10+1;
      else
        ratioNumber10=ratioNumber10;
      end
  end
  
  for m=NSE-N1+1:1:c-N1-N2
      if (ind(m)==2)
          ratioNumber10=ratioNumber10+1;
      else
        ratioNumber10=ratioNumber10;
      end
  end
  

    
    
  ratio10(1,time)=ratioNumber10/(c-N1-N2);
  
  
  
end

 ratiomean1=sum(ratio1)/Number;
 

ratiomean2=sum(ratio2)/Number;
 


 ratiomean3=sum(ratio3)/Number;
 
 
 ratiomean4=sum(ratio4)/Number;
 
 ratiomean5=sum(ratio5)/Number;
 
 
 ratiomean6=sum(ratio6)/Number;
 
 ratiomean7=sum(ratio7)/Number;
 
 
 ratiomean8=sum(ratio8)/Number;
 
 ratiomean9=sum(ratio9)/Number;
 
 
 ratiomean10=sum(ratio10)/Number;
 

 
 ratio=[ratio1;ratio2;ratio3;ratio4;ratio5;ratio6;ratio7;ratio8;ratio9;ratio10];
 
 
 ratiomean=[ratiomean1,ratiomean2,ratiomean3,ratiomean4,ratiomean5,ratiomean6,ratiomean7,ratiomean8,ratiomean9,ratiomean10]';
 rationumber(:,kkk)=ratiomean;
 ratio_Knumber(:,kkk)=[sum(sum(Kumber1));sum(sum(Kumber2));sum(sum(Kumber3));sum(sum(Kumber4));sum(sum(Kumber5))]/(Number*(r-1)*(c-N1-N2));
end
 

rationumber
ratio_Knumber
    xlswrite('C:\Users\Li_Peng_Pan\Desktop\INS-D-22-5070\CSE_INS\INS_matlab\application\Newfertility_Diagnosis_CET\rationumber_FD.csv',rationumber)
    xlswrite('C:\Users\Li_Peng_Pan\Desktop\INS-D-22-5070\CSE_INS\INS_matlab\application\Newfertility_Diagnosis_CET\ratio_Knumber_FD.csv',ratio_Knumber)  
 