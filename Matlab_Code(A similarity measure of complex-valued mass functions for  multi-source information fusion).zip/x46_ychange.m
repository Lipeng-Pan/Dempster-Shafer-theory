clc;close all; clear;
% tic
Nub=10;
S=zeros(1,Nub);
SumS=zeros(5,Nub);




S(1)=1;
y=0;
for k=2:1:Nub
    N=k;
    BPAnub=2^N-1;
    BPA1=zeros(1,BPAnub);
    BPA2=zeros(1,BPAnub);
    BPA1(1)=0.1+i*y/2;
    BPA1(BPAnub)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(1)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(BPAnub)=0.1+i*y/2;
    sheet=k;
    filename = 'Dmatix.xlsx';
    DD=xlsread(filename,sheet);
    S(k)=abs(BPA1*DD*BPA2')/((BPA1*DD*BPA1')^0.5*(BPA2*DD*BPA2')^0.5);
    S(k)=abs(S(k));
end
S;

SumS(1,:)=S;

y=0.1;
for k=2:1:Nub
    N=k;
    BPAnub=2^N-1;
    BPA1=zeros(1,BPAnub);
    BPA2=zeros(1,BPAnub);
    BPA1(1)=0.1+i*y/2;
    BPA1(BPAnub)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(1)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(BPAnub)=0.1+i*y/2;
    sheet=k;
    filename = 'Dmatix.xlsx';
    DD=xlsread(filename,sheet);
    S(k)=abs(BPA1*DD*BPA2')/((BPA1*DD*BPA1')^0.5*(BPA2*DD*BPA2')^0.5);
    S(k)=abs(S(k));
end
S;

SumS(2,:)=S;

y=0.2;
for k=2:1:Nub
    N=k;
    BPAnub=2^N-1;
    BPA1=zeros(1,BPAnub);
    BPA2=zeros(1,BPAnub);
    BPA1(1)=0.1+i*y/2;
    BPA1(BPAnub)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(1)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(BPAnub)=0.1+i*y/2;
    sheet=k;
    filename = 'Dmatix.xlsx';
    DD=xlsread(filename,sheet);
    S(k)=abs(BPA1*DD*BPA2')/((BPA1*DD*BPA1')^0.5*(BPA2*DD*BPA2')^0.5);
    S(k)=abs(S(k));
end
S;

SumS(3,:)=S;

y=0.3;
for k=2:1:Nub
    N=k;
    BPAnub=2^N-1;
    BPA1=zeros(1,BPAnub);
    BPA2=zeros(1,BPAnub);
    BPA1(1)=0.1+i*y/2;
    BPA1(BPAnub)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(1)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(BPAnub)=0.1+i*y/2;
    sheet=k;
    filename = 'Dmatix.xlsx';
    DD=xlsread(filename,sheet);
    S(k)=abs(BPA1*DD*BPA2')/((BPA1*DD*BPA1')^0.5*(BPA2*DD*BPA2')^0.5);
    S(k)=abs(S(k));
end
S;

SumS(4,:)=S;


y=0.4;
for k=2:1:Nub
    N=k;
    BPAnub=2^N-1;
    BPA1=zeros(1,BPAnub);
    BPA2=zeros(1,BPAnub);
    BPA1(1)=0.1+i*y/2;
    BPA1(BPAnub)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(1)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(BPAnub)=0.1+i*y/2;
    sheet=k;
    filename = 'Dmatix.xlsx';
    DD=xlsread(filename,sheet);
    S(k)=abs(BPA1*DD*BPA2')/((BPA1*DD*BPA1')^0.5*(BPA2*DD*BPA2')^0.5);
    S(k)=abs(S(k));
end
S;

SumS(5,:)=S;



y=0.5;
for k=2:1:Nub
    N=k;
    BPAnub=2^N-1;
    BPA1=zeros(1,BPAnub);
    BPA2=zeros(1,BPAnub);
    BPA1(1)=0.1+i*y/2;
    BPA1(BPAnub)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(1)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(BPAnub)=0.1+i*y/2;
   sheet=k;
    filename = 'Dmatix.xlsx';
    DD=xlsread(filename,sheet);
    S(k)=abs(BPA1*DD*BPA2')/((BPA1*DD*BPA1')^0.5*(BPA2*DD*BPA2')^0.5);
    S(k)=abs(S(k));
end
S;

SumS(6,:)=S;

S(1)=1;
y=0.6;
for k=2:1:Nub
    N=k;
    BPAnub=2^N-1;
    BPA1=zeros(1,BPAnub);
    BPA2=zeros(1,BPAnub);
    BPA1(1)=0.1+i*y/2;
    BPA1(BPAnub)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(1)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(BPAnub)=0.1+i*y/2;
    sheet=k;
    filename = 'Dmatix.xlsx';
    DD=xlsread(filename,sheet);
    S(k)=abs(BPA1*DD*BPA2')/((BPA1*DD*BPA1')^0.5*(BPA2*DD*BPA2')^0.5);
    S(k)=abs(S(k));
end
S;
% t=toc
SumS(7,:)=S;

y=0.7;
for k=2:1:Nub
    N=k;
    BPAnub=2^N-1;
    BPA1=zeros(1,BPAnub);
    BPA2=zeros(1,BPAnub);
    BPA1(1)=0.1+i*y/2;
    BPA1(BPAnub)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(1)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(BPAnub)=0.1+i*y/2;
    sheet=k;
    filename = 'Dmatix.xlsx';
    DD=xlsread(filename,sheet);
    S(k)=abs(BPA1*DD*BPA2')/((BPA1*DD*BPA1')^0.5*(BPA2*DD*BPA2')^0.5);
    S(k)=abs(S(k));
end
S;

SumS(8,:)=S;

y=0.8;
for k=2:1:Nub
    N=k;
    BPAnub=2^N-1;
    BPA1=zeros(1,BPAnub);
    BPA2=zeros(1,BPAnub);
    BPA1(1)=0.1+i*y/2;
    BPA1(BPAnub)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(1)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(BPAnub)=0.1+i*y/2;
    sheet=k;
    filename = 'Dmatix.xlsx';
    DD=xlsread(filename,sheet);
    S(k)=abs(BPA1*DD*BPA2')/((BPA1*DD*BPA1')^0.5*(BPA2*DD*BPA2')^0.5);
    S(k)=abs(S(k));
end
S;

SumS(9,:)=S;

y=0.9;
for k=2:1:Nub
    N=k;
    BPAnub=2^N-1;
    BPA1=zeros(1,BPAnub);
    BPA2=zeros(1,BPAnub);
    BPA1(1)=0.1+i*y/2;
    BPA1(BPAnub)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(1)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(BPAnub)=0.1+i*y/2;
    sheet=k;
    filename = 'Dmatix.xlsx';
    DD=xlsread(filename,sheet);
    S(k)=abs(BPA1*DD*BPA2')/((BPA1*DD*BPA1')^0.5*(BPA2*DD*BPA2')^0.5);
    S(k)=abs(S(k));
end
S;

SumS(10,:)=S;


y=0.99;
for k=2:1:Nub
    N=k;
    BPAnub=2^N-1;
    BPA1=zeros(1,BPAnub);
    BPA2=zeros(1,BPAnub);
    BPA1(1)=0.1+i*y/2;
    BPA1(BPAnub)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(1)=(1/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5+i*(3/4*(1-(0.01+(y^2)/4)^0.5)^2)^0.5;
    BPA2(BPAnub)=0.1+i*y/2;
    sheet=k;
    filename = 'Dmatix.xlsx';
    DD=xlsread(filename,sheet);
    S(k)=abs(BPA1*DD*BPA2')/((BPA1*DD*BPA1')^0.5*(BPA2*DD*BPA2')^0.5);
    S(k)=abs(S(k));
end
S;

SumS(11,:)=S;

