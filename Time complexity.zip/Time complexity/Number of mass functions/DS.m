function [outputArg1] = DS(BPA1_1,BPA1_2)  % DRC
%
% Many thanks to Ph.D. student Lipeng Pan!
% Matrix = BPA1'*BPA2���������� orthoganal
% ��Matrix.*F?��ɸѡ��Ҫ��Ԫ�� Ȼ����� ����һ��
%

F1=[1     0     0     1     1     0     1
    0     0     0     0     0     0     0
    0     0     0     0     0     0     0
    1     0     0     0     1     0     0
    1     0     0     1     0     0     0
    0     0     0     0     0     0     0
    1     0     0     0     0     0     0];

F2=[0     0     0     0     0     0     0
    0     1     0     1     0     1     1
    0     0     0     0     0     0     0
    0     1     0     0     0     1     0
    0     0     0     0     0     0     0
    0     1     0     1     0     0     0
    0     1     0     0     0     0     0];

F3=[0     0     0     0     0     0     0
    0     0     0     0     0     0     0
    0     0     1     0     1     1     1
    0     0     0     0     0     0     0
    0     0     1     0     0     1     0
    0     0     1     0     1     0     0
    0     0     1     0     0     0     0];

F4=[0     0     0     0     0     0     0
    0     0     0     0     0     0     0
    0     0     0     0     0     0     0
    0     0     0     1     0     0     1
    0     0     0     0     0     0     0
    0     0     0     0     0     0     0
    0     0     0     1     0     0     0];

F5=[0     0     0     0     0     0     0
    0     0     0     0     0     0     0
    0     0     0     0     0     0     0
    0     0     0     0     0     0     0
    0     0     0     0     1     0     1
    0     0     0     0     0     0     0
    0     0     0     0     1     0     0];

F6=[0     0     0     0     0     0     0
    0     0     0     0     0     0     0
    0     0     0     0     0     0     0
    0     0     0     0     0     0     0
    0     0     0     0     0     0     0
    0     0     0     0     0     1     1
    0     0     0     0     0     1     0];

F7=[0     0     0     0     0     0     0
    0     0     0     0     0     0     0
    0     0     0     0     0     0     0
    0     0     0     0     0     0     0
    0     0     0     0     0     0     0
    0     0     0     0     0     0     0
    0     0     0     0     0     0     1];
 
Matrix = BPA1_1' *BPA1_2;

unnormalized=[sum(sum(Matrix.*F1)),sum(sum(Matrix.*F2)),sum(sum(Matrix.*F3)),sum(sum(Matrix.*F4)),sum(sum(Matrix.*F5)),sum(sum(Matrix.*F6)),sum(sum(Matrix.*F7))];

outputArg1 = unnormalized./sum(unnormalized);


end

