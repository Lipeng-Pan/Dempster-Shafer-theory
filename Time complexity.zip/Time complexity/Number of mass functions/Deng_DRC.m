function [ ]=Deng_DRC(i_mass) %The method of Deng et al.
c=3;
DD=[1 0 0 1/2 1/2 0 1/3
    0 1 0 1/2 0 1/2 1/3
    0 0 1 0 1/2 1/2 1/3
    1/2 1/2 0 1 1/3 1/3 2/3
    1/2 0 1/2 1/3 1 1/3 2/3
    0 1/2 1/2 1/3 1/3 1 2/3
    1/3 1/3 1/3 2/3 2/3 2/3 1];


mass_function_1=rand(i_mass,2^c-1);
mass_function_1=mass_function_1./sum(mass_function_1);


 Odynamicweight_Deng=zeros(i_mass,i_mass);
   
   for i_deng=1:1:i_mass
       for j_deng=1:1:i_mass
           Odynamicweight_Deng(i_deng,j_deng)=(((mass_function_1(i_deng,:)-mass_function_1(j_deng,:))*DD*(mass_function_1(i_deng,:)-mass_function_1(j_deng,:))')/2)^0.5;
       end
   end
   
   
   dynamicweight_Deng=(sum(1-Odynamicweight_Deng,2)-1)/sum(sum(1-Odynamicweight_Deng,2)-1);
   
   DBPA=sum(dynamicweight_Deng.*mass_function_1);




   mp1=DBPA;
   mp2=DBPA;
     [outputArg1]=DS(mp1,mp2);
     for mmk=3:1:i_mass
         mp1=outputArg1;
         mp2=DBPA;
         [outputArg1]=DS(mp1,mp2);
     end
   


end