function [ ]=Dis_Q_DRC(i_mass) % The proposed fusion method
c=3;
NN=2^c-1;
   R=[1.0000         0         0    0.5000    0.5000         0    0.3333
      0    1.0000         0    0.5000         0    0.5000    0.3333
      0         0    1.0000         0    0.5000    0.5000    0.3333
      0.5000    0.5000         0    1.0000    0.3333    0.3333    0.6667
      0.5000         0    0.5000    0.3333    1.0000    0.3333    0.6667
      0    0.5000    0.5000    0.3333    0.3333    1.0000    0.6667
      0.3333    0.3333    0.3333    0.6667    0.6667    0.6667    1.0000];


mass_function_1_R=rand(i_mass,2^c-1);
mass_function_1_I=rand(i_mass,2^c-1);
mass_function_1=mass_function_1_R+1i*mass_function_1_I;

mass_function_1=(mass_function_1.^2./(sum(( abs(mass_function_1)).^2,2))).^0.5; 





     p=2;
      weight_Dis_Q=zeros(i_mass,i_mass);
      for wi=1:1:i_mass
          for wj=1:1:i_mass
              CM1=mass_function_1(wi,:);
              CM2=mass_function_1(wj,:);
              weight_Dis_Q(wi,wj)=(((R*(CM1-CM2).').^(p/2))'*((R*(CM1-CM2).').^(p/2))/(CM1.^(p/2)*(CM1.^(p/2))'+CM2.^(p/2)*(CM2.^(p/2))'))^0.5;
          end
      end
              
    Dis=[((i_mass-1-sum(weight_Dis_Q,2))/sum(i_mass-1-sum(weight_Dis_Q,2))).^0.5.*mass_function_1(:,1:NN-1),sum( (1-(i_mass-1-sum(weight_Dis_Q,2))/sum(i_mass-1-sum(weight_Dis_Q,2))).^0.5.*mass_function_1(:,1:NN-1),2)+mass_function_1(:,NN)];  
    Dis=(Dis.^2./(sum(( abs(Dis)).^2,2))).^0.5;


    
    mp1=Dis(1,:);
    mp2=Dis(2,:);
    [outputArg1] = CDS(mp1,mp2);
    for mc=3:1:i_mass
        mp1=outputArg1;
        mp2=Dis(mc,:);
        [outputArg1]= CDS(mp1,mp2);
    end
   


end