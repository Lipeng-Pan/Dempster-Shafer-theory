function [ ]=Xiao_DRC(i_mass)  %The method of Xiao
c=3;



mass_function_1=rand(i_mass,2^c-1);
mass_function_1=mass_function_1./sum(mass_function_1);


 Odynamicweight_Xiao=zeros(i_mass,i_mass);
 

   for i_Xiao=1:1:i_mass
       for j_Xiao=1:1:i_mass
            Odynamicweight_Xiao(i_Xiao,j_Xiao)=(sum(mass_function_1(i_Xiao,:).*log2(2*mass_function_1(i_Xiao,:)./(mass_function_1(i_Xiao,:)+mass_function_1(j_Xiao,:)))+mass_function_1(j_Xiao,:).*log2(2*mass_function_1(j_Xiao,:)./(mass_function_1(i_Xiao,:)+mass_function_1(j_Xiao,:)))))/2;
       end
   end
   
   
   dynamicweight_Xiao=(sum(1-Odynamicweight_Xiao,2)-1)/sum(sum(1-Odynamicweight_Xiao,2)-1);
   
   XBPA=sum(dynamicweight_Xiao.*mass_function_1);




   mp1=XBPA;
   mp2=XBPA;
     [outputArg1]=DS(mp1,mp2);
     for mmk=3:1:i_mass
         mp1=outputArg1;
         mp2=XBPA;
         [outputArg1]=DS(mp1,mp2);
     end
   


end