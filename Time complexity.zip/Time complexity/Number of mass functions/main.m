
% The size of the frame of discernment is 3
% 
% p=2


II_Time=100;

I_MASS_number=100;

I_MASS_V=zeros(6,I_MASS_number-1);




kkk=0;
N1=2;
for i_mass=N1:1:I_MASS_number
    kkk=kkk+1
    

Time_V=zeros(6,II_Time);
for i_time=2:1:II_Time+1

tic
DRC(i_mass)
Time_V(1,i_time-1)=toc;

tic
M_DRC(i_mass)
Time_V(2,i_time-1)=toc;


tic
Deng_DRC(i_mass)
Time_V(3,i_time-1)=toc;

tic
Xiao_DRC(i_mass)
Time_V(4,i_time-1)=toc;



tic
Q_DRC(i_mass)
Time_V(5,i_time-1)=toc;


tic
Dis_Q_DRC(i_mass)
Time_V(6,i_time-1)=toc;
end

I_MASS_V(:,kkk)=sum(Time_V,2);
end
I_MASS_V
     xlswrite('/Users/panlipeng/Desktop/application/Z_computational complexity/Mass/I_MASS_V.csv',I_MASS_V)