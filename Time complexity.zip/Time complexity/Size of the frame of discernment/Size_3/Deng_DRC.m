function [ ]=Deng_DRC(str_O_0,AA,i_time)
%δ�ӿռ�
% DD=[1 0 0 1/2 1/2 0 1/3
%     0 1 0 1/2 0 1/2 1/3
%     0 0 1 0 1/2 1/2 1/3
%     1/2 1/2 0 1 1/3 1/3 2/3
%     1/2 0 1/2 1/3 1 1/3 2/3
%     0 1/2 1/2 1/3 1/3 1 2/3
%     1/3 1/3 1/3 2/3 2/3 2/3 1];
% clc
% clear all
% tic
for ii_Deng_DRC=1:1:i_time
% str_O_0=char('a','b'); %Ԫ�ر仯����Ҫ�޸�
%   str_O_0=char('a','b','c');
% str_O_0=char('a','b','c','d');
% str_O_0=char('a','b','c','d','e');
% str_O_0=char('a','b','c','d','e','f');
[c,r]=size(str_O_0);
 str_O_1_math=zeros(1,c^c);
 str_O_1=string(str_O_1_math);
 str_O_2=string(str_O_1_math);


% [a11,b11]=ndgrid(string(str_O_0));  %ȫ�������  Ԫ�ر仯����Ҫ�滻
%  AA=[a11(:),b11(:)];     %Ԫ�ر仯����Ҫ�޸�

% [a11,b11,c11]=ndgrid(string(str_O_0));  %ȫ�������  Ԫ�ر仯����Ҫ�滻
%  AA=[a11(:),b11(:),c11(:)];     %Ԫ�ر仯����Ҫ�޸�

% [a11,b11,c11,d11]=ndgrid(string(str_O_0));  %ȫ�������  Ԫ�ر仯����Ҫ�滻
%  AA=[a11(:),b11(:),c11(:),d11(:)];     %Ԫ�ر仯����Ҫ�޸�
% 
%  [a11,b11,c11,d11,e11]=ndgrid(string(str_O_0));  %ȫ�������  Ԫ�ر仯����Ҫ�滻
%  AA=[a11(:),b11(:),c11(:),d11(:),e11(:)];     %Ԫ�ر仯����Ҫ�޸�
 
%  [a11,b11,c11,d11,e11,f11]=ndgrid(string(str_O_0));  %ȫ�������  Ԫ�ر仯����Ҫ�滻
%  AA=[a11(:),b11(:),c11(:),d11(:),e11(:),f11(:)];     %Ԫ�ر仯����Ҫ�޸�
 
 

mass_function_1=rand(1,2^c-1);
mass_function_1=mass_function_1/sum(mass_function_1);

mass_function_2=rand(1,2^c-1);
mass_function_2=mass_function_2/sum(mass_function_2);

mass_function_1=(mass_function_1+mass_function_2)/2;
mass_function_2=mass_function_1;

Deng_mass_function_12=[mass_function_1;mass_function_2];

 

mass_function_12=zeros(1,2^c-1);
for i1=1:1:c^c
%     str_O_1(i1)=[char(AA(i1,1)),char(AA(i1,2))]; 
    str_O_1(i1)=[char(AA(i1,1)),char(AA(i1,2)),char(AA(i1,3))];   %Ԫ�ر仯����Ҫ�޸�
%     str_O_1(i1)=[char(AA(i1,1)),char(AA(i1,2)),char(AA(i1,3)),char(AA(i1,4))];   %Ԫ�ر仯����Ҫ�޸�
%     str_O_1(i1)=[char(AA(i1,1)),char(AA(i1,2)),char(AA(i1,3)),char(AA(i1,4)),char(AA(i1,5))];   %Ԫ�ر仯����Ҫ�޸�
%       str_O_1(i1)=[char(AA(i1,1)),char(AA(i1,2)),char(AA(i1,3)),char(AA(i1,4)),char(AA(i1,5)),char(AA(i1,6))];   %Ԫ�ر仯����Ҫ�޸�
end







for i1=1:1:c^c
    A=char(str_O_1(i1));
    str_O_2(i1)=unique(A);
end

str_O_2=unique(str_O_2);
Idx=zeros(2^c-1,2);
for i1=1:1:2^c-1
    A=char(str_O_2(i1));
    [c1,r1]=size(A);
    Idx(i1,:)=[r1,i1];
end
Idx;


str_O_3="";
for k=1:1:c
    A_number=find(Idx(:,1)==k);
    str_O_3=[str_O_3,str_O_2(A_number)];
   
end

 Str_mass_functions=str_O_3(2:2^c);
 Str_mass_functions=char(Str_mass_functions);
 M_DS_D=zeros(2^c-1,2^c-1);
 
for i0=1:1: 2^c-1
for i1=1:1:2^c-1
    for i2=1:1:2^c-1
        B=strrep(Str_mass_functions(:,:,i1), ' ', '');
        A=strrep(Str_mass_functions(:,:,i2), ' ', '');
        perms_vaule=strcmp(strrep((intersect(B,A)),' ', ''),strrep((Str_mass_functions(:,:,i0)),' ', ''));
        
        if (sum(perms_vaule)==0)
             M_DS(i1,i2)=0;
        else
            M_DS(i1,i2)=1;
        end
        
        
    end
end


for i1=1:1:2^c-1
    for i2=1:1:2^c-1
        B=strrep(Str_mass_functions(:,:,i1), ' ', '');
        A=strrep(Str_mass_functions(:,:,i2), ' ', '');
        perms_vaule=strcmp(strrep((intersect(B,A)),' ', ''),strrep((Str_mass_functions(:,:,i0)),' ', ''));
        
        if (sum(perms_vaule)==0)
             M_DS_D(i1,i2)=0;
        else
            M_DS_D(i1,i2)=1;
        end
        
        
    end
end

  Odynamicweight_Deng=zeros(3-1,3-1);
   
   for i_Deng=1:1:2
       for j_Deng=1:1:2
           Odynamicweight_Deng(i_Deng,j_Deng)=(((Deng_mass_function_12(i_Deng,:)-Deng_mass_function_12(j_Deng,:))*M_DS_D*(Deng_mass_function_12(i_Deng,:)-Deng_mass_function_12(j_Deng,:))')/2)^0.5;
       end
   end
   
   
   dynamicweight_Deng=(sum(1-Odynamicweight_Deng,2)-1)/sum(sum(1-Odynamicweight_Deng,2)-1);
   
   D_BPA=sum(dynamicweight_Deng.*Deng_mass_function_12);


mass_function_1=D_BPA;
mass_function_2=D_BPA;


mass_function_12_Matrix=mass_function_1'.*mass_function_2;
mass_function_12(1,i0)=sum(sum(M_DS.*mass_function_12_Matrix));

end

mass_function_12=mass_function_12/sum(mass_function_12);

end

% toc
% 
% ii_Deng_DRC
end
