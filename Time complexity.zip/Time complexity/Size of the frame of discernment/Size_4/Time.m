
str_O_0=char('a','b','c','d');

[a11,b11,c11,d11]=ndgrid(string(str_O_0));  %ȫ�������  Ԫ�ر仯����Ҫ�滻
 AA=[a11(:),b11(:),c11(:),d11(:)];     %Ԫ�ر仯����Ҫ�޸�
% str_O_0=char('a','b','c','d','e');
% str_O_0=char('a','b','c','d','e','f');
%  [a11,b11,c11,d11,e11,f11]=ndgrid(string(str_O_0));  %ȫ�������  Ԫ�ر仯����Ҫ�滻
%  AA=[a11(:),b11(:),c11(:),d11(:),e11(:),f11(:)];     %Ԫ�ر仯����Ҫ�޸�
 
  i_time=1;

 I_TIME_Number=1000;
 
 TIME_VAULE=zeros(6,I_TIME_Number);
 
 
 for i_i_vaule=1:1:I_TIME_Number
 i_i_vaule
 tic
DRC(str_O_0,AA,i_time);
TIME_VAULE(1,i_i_vaule)=toc;

tic
M_DRC(str_O_0,AA,i_time);
TIME_VAULE(2,i_i_vaule)=toc;

tic
Deng_DRC(str_O_0,AA,i_time);
TIME_VAULE(3,i_i_vaule)=toc;

tic
Xiao_DRC(str_O_0,AA,i_time);
TIME_VAULE(4,i_i_vaule)=toc;

tic
Q_DRC(str_O_0,AA,i_time);
TIME_VAULE(5,i_i_vaule)=toc;


tic
Dis_Q_DRC(str_O_0,AA,i_time);
TIME_VAULE(6,i_i_vaule)=toc;
 end
  TIME_VAULEmean=sum(TIME_VAULE,2)/I_TIME_Number;
 TIME_VAULEmean'